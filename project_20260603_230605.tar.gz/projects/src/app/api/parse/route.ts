import { NextRequest, NextResponse } from 'next/server';
import { parseExcelFile } from '@/lib/excel-utils';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    const headerRowStr = formData.get('headerRow') as string | null;
    const headerRow = headerRowStr ? parseInt(headerRowStr, 10) : 1;

    if (!file) {
      return NextResponse.json({ error: '未提供文件' }, { status: 400 });
    }

    // 验证文件类型
    const validExtensions = ['.xls', '.xlsx'];
    const fileName = file.name.toLowerCase();
    const isValidExtension = validExtensions.some(ext => fileName.endsWith(ext));
    if (!isValidExtension) {
      return NextResponse.json({ error: '仅支持 .xls 和 .xlsx 格式的文件' }, { status: 400 });
    }

    const result = await parseExcelFile(file, headerRow);

    if ('error' in result) {
      return NextResponse.json({ error: result.error }, { status: 400 });
    }

    // 不返回原始 File 对象，只返回文件信息
    const fileInfoForClient = {
      id: result.fileInfo.id,
      name: result.fileInfo.name,
      sheetNames: result.fileInfo.sheetNames,
      selectedSheet: result.fileInfo.selectedSheet,
      headerRow: result.fileInfo.headerRow,
      rowCount: result.fileInfo.rowCount,
      columnCount: result.fileInfo.columnCount,
      isValid: result.fileInfo.isValid,
      errorMessage: result.fileInfo.errorMessage,
      // 使用临时文件路径或 ID 作为文件标识
      fileId: result.fileInfo.id,
    };

    return NextResponse.json({
      success: true,
      fileInfo: fileInfoForClient,
      sheetData: result.sheetData,
    });
  } catch (error) {
    console.error('文件解析错误:', error);
    return NextResponse.json(
      { error: `解析失败: ${error instanceof Error ? error.message : '未知错误'}` },
      { status: 500 }
    );
  }
}