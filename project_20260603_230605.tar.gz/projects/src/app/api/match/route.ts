import { NextRequest, NextResponse } from 'next/server';
import { parseExcelFile, executeMatch } from '@/lib/excel-utils';
import type { MatchExecuteRequest, MatchFileConfig, SheetData } from '@/lib/types';

// 临时存储解析后的文件数据（实际生产环境应使用更可靠的存储方案）
const parsedFilesCache = new Map<string, Awaited<ReturnType<typeof parseExcelFile>>>();

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const configStr = formData.get('config') as string | null;

    if (!configStr) {
      return NextResponse.json({ error: '未提供配置信息' }, { status: 400 });
    }

    const config: MatchExecuteRequest = JSON.parse(configStr);

    // 验证主文件
    const mainFile = formData.get('mainFile') as File | null;
    if (!mainFile && !config.mainFileConfig.file) {
      return NextResponse.json({ error: '未提供主文件' }, { status: 400 });
    }

    // 解析主文件
    let mainFileData;
    if (mainFile) {
      const mainResult = await parseExcelFile(mainFile, config.mainFileConfig.headerRow);
      if ('error' in mainResult) {
        return NextResponse.json({ error: `主文件解析失败: ${mainResult.error}` }, { status: 400 });
      }
      mainFileData = mainResult.sheetData;
    } else {
      // 尝试从缓存获取
      const cached = parsedFilesCache.get(config.mainFileConfig.file?.id || '');
      if (!cached || 'error' in cached) {
        return NextResponse.json({ error: '主文件数据已过期，请重新上传' }, { status: 400 });
      }
      mainFileData = cached.sheetData;
    }

    // 解析匹配文件
    const matchFileData = new Map<string, SheetData>();
    const matchFilesEntries = formData.getAll('matchFiles');

    // 调试日志：检查配置
    console.log('匹配文件配置数量:', config.matchFileConfigs.length);
    console.log('上传匹配文件数量:', matchFilesEntries.length);

    for (let i = 0; i < matchFilesEntries.length; i++) {
      const file = matchFilesEntries[i] as File;
      
      // 通过文件名查找配置，支持多种匹配方式
      const matchConfig = config.matchFileConfigs.find(c => 
        c.file.name === file.name || 
        c.id.includes(file.name.replace(/\.[^/.]+$/, '')) ||
        c.id === `match-${file.name}`
      );
      
      console.log(`处理文件 ${file.name}, 找到配置:`, matchConfig?.id || '未找到');
      
      if (!matchConfig) {
        console.warn(`未找到匹配文件 ${file.name} 的配置`);
        continue;
      }

      const result = await parseExcelFile(file, matchConfig.file.headerRow || 1);
      if ('error' in result) {
        console.warn(`匹配文件 ${file.name} 解析失败: ${result.error}`);
        continue;
      }

      // 使用配置ID作为键，而不是文件名
      matchFileData.set(matchConfig.id, result.sheetData);
      console.log(`文件 ${file.name} 解析成功，行数:`, result.sheetData.rowCount);
    }

    // 执行匹配
    const matchResult = await executeMatch(
      mainFileData,
      matchFileData,
      config.mainFileConfig,
      config.matchFileConfigs,
      config.globalStorageConfig,
      config.nullValueConfig
    );

    return NextResponse.json({
      success: true,
      result: matchResult,
    });
  } catch (error) {
    console.error('匹配执行错误:', error);
    return NextResponse.json(
      { error: `匹配失败: ${error instanceof Error ? error.message : '未知错误'}` },
      { status: 500 }
    );
  }
}