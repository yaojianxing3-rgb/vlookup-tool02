import { NextRequest, NextResponse } from 'next/server';
import { exportToExcel, exportMatchLogs, exportUnmatchedList } from '@/lib/excel-utils';
import type { ExportExecuteRequest } from '@/lib/types';

export async function POST(request: NextRequest) {
  try {
    const config: ExportExecuteRequest = await request.json();

    // 导出主结果文件
    const mainBuffer = exportToExcel(
      config.matchResult.outputData,
      config.matchResult.outputHeaders,
      '匹配结果.xlsx'
    );

    const results: {
      mainFile?: string;
      logFile?: string;
      unmatchedFile?: string;
    } = {};

    // 将Buffer转为 base64 以便前端下载
    results.mainFile = Buffer.from(mainBuffer).toString('base64');

    // 导出匹配日志
    if (config.exportConfig.includeMatchLog && config.matchResult.matchLogs.length > 0) {
      const logBuffer = exportMatchLogs(config.matchResult.matchLogs);
      results.logFile = Buffer.from(logBuffer).toString('base64');
    }

    // 导出未匹配清单
    if (config.exportConfig.includeUnmatchedList && config.matchResult.unmatchedRecords.length > 0) {
      const unmatchedBuffer = exportUnmatchedList(config.matchResult.unmatchedRecords);
      results.unmatchedFile = Buffer.from(unmatchedBuffer).toString('base64');
    }

    return NextResponse.json({
      success: true,
      files: results,
    });
  } catch (error) {
    console.error('导出错误:', error);
    return NextResponse.json(
      { error: `导出失败: ${error instanceof Error ? error.message : '未知错误'}` },
      { status: 500 }
    );
  }
}