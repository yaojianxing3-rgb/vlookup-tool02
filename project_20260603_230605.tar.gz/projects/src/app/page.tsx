'use client';

import { useState, useCallback } from 'react';
import type {
  SheetData,
  MainFileConfig,
  MatchFileConfig,
  GlobalStorageConfig,
  NullValueConfig,
  MatchResult,
  ColumnInfo,
} from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

const defaultGlobalStorageConfig: GlobalStorageConfig = {
  defaultRule: {
    mode: 'same-name-fill',
    sameNameFillMode: 'fill-blank-only',
    newColumnNaming: 'filename-column',
  },
  duplicateKeyHandling: 'first-match',
  noMatchFill: '#N/A',
};

const defaultNullValueConfig: NullValueConfig = {
  globalFill: '#N/A',
};

// 步骤定义
const STEPS = [
  { id: 1, title: '上传主文件', description: '选择基准Excel文件' },
  { id: 2, title: '添加匹配文件', description: '导入辅表文件' },
  { id: 3, title: '配置规则', description: '设置匹配参数' },
  { id: 4, title: '执行匹配', description: '运行并导出结果' },
];

export default function VlookupToolPage() {
  // 状态管理
  const [mainSheetData, setMainSheetData] = useState<SheetData | null>(null);
  const [matchSheetDataList, setMatchSheetDataList] = useState<{ id: string; data: SheetData; file: File }[]>([]);
  const [mainFile, setMainFile] = useState<File | null>(null);
  const [selectedMainColumns, setSelectedMainColumns] = useState<string[]>([]);
  // 改为多选匹配列数组
  const [matchKeyColumns, setMatchKeyColumns] = useState<string[]>([]);
  const [selectedMatchColumns, setSelectedMatchColumns] = useState<Record<string, string[]>>({});
  // 每个匹配文件的匹配列也改为数组
  const [matchKeyColumnsPerFile, setMatchKeyColumnsPerFile] = useState<Record<string, string[]>>({});
  const [storageConfig, setStorageConfig] = useState<GlobalStorageConfig>(defaultGlobalStorageConfig);
  const [nullValueConfig, setNullValueConfig] = useState<NullValueConfig>(defaultNullValueConfig);
  const [matchResult, setMatchResult] = useState<MatchResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeFileId, setActiveFileId] = useState<string | null>(null);

  // 计算当前步骤
  const currentStep = !mainSheetData ? 1 : matchSheetDataList.length === 0 ? 2 : matchKeyColumns.length === 0 ? 3 : matchResult ? 4 : 3;

  // 上传主文件
  const handleMainFileUpload = useCallback(async (file: File) => {
    setIsProcessing(true);
    setError(null);
    
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('headerRow', '1');

      const response = await fetch('/api/parse', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        setError(result.error || '文件解析失败');
        return;
      }

      setMainFile(file);
      setMainSheetData(result.sheetData);
      setSelectedMainColumns(result.sheetData.headers);
      setMatchKeyColumns([]);
      setMatchResult(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : '文件上传失败');
    } finally {
      setIsProcessing(false);
    }
  }, []);

  // 上传匹配文件
  const handleMatchFilesUpload = useCallback(async (files: FileList) => {
    setIsProcessing(true);
    setError(null);
    
    try {
      const newItems: { id: string; data: SheetData; file: File }[] = [];

      for (const file of Array.from(files)) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('headerRow', '1');

        const response = await fetch('/api/parse', {
          method: 'POST',
          body: formData,
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
          setError(`文件 ${file.name} 解析失败: ${result.error}`);
          continue;
        }

        const id = `match-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
        newItems.push({ id, data: result.sheetData, file });
        setSelectedMatchColumns(prev => ({ ...prev, [id]: [] }));
        // 每个匹配文件默认使用主文件的匹配列
        setMatchKeyColumnsPerFile(prev => ({ ...prev, [id]: matchKeyColumns }));
      }

      if (newItems.length > 0) {
        setMatchSheetDataList(prev => [...prev, ...newItems]);
        setActiveFileId(newItems[0].id);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : '文件上传失败');
    } finally {
      setIsProcessing(false);
    }
  }, [matchKeyColumns]);

  // 执行匹配
  const handleExecuteMatch = useCallback(async () => {
    if (!mainSheetData || matchSheetDataList.length === 0 || matchKeyColumns.length === 0) {
      setError('请先上传主文件和匹配文件，并选择至少一个匹配关键字列');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      const mainFileConfig: MainFileConfig = {
        file: null,
        selectedColumns: selectedMainColumns,
        matchKeyColumns: matchKeyColumns,
        headerRow: 1,
        preprocessKey: true,
        matchVisibleRowsOnly: false,
      };

      const matchFileConfigs: MatchFileConfig[] = matchSheetDataList.map((item, index) => ({
        id: item.id,
        file: {
          id: item.id,
          name: item.file.name,
          sheetNames: [],
          selectedSheet: '',
          headerRow: 1,
          rowCount: item.data.rowCount,
          columnCount: item.data.columnCount,
          isValid: true,
        },
        enabled: true,
        order: index,
        selectedColumns: selectedMatchColumns[item.id] || [],
        matchKeyColumns: matchKeyColumnsPerFile[item.id] || matchKeyColumns,
      }));

      const formData = new FormData();
      formData.append('mainFile', mainFile!);
      formData.append('config', JSON.stringify({
        mainFileConfig: { ...mainFileConfig, file: null },
        matchFileConfigs: matchFileConfigs.map(c => ({ ...c, file: { ...c.file } })),
        globalStorageConfig: storageConfig,
        nullValueConfig,
      }));

      matchSheetDataList.forEach(item => {
        formData.append('matchFiles', item.file);
      });

      const response = await fetch('/api/match', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        setError(result.error || '匹配执行失败');
        return;
      }

      setMatchResult(result.result);
    } catch (err) {
      setError(err instanceof Error ? err.message : '匹配执行失败');
    } finally {
      setIsProcessing(false);
    }
  }, [mainSheetData, matchSheetDataList, matchKeyColumns, selectedMainColumns, selectedMatchColumns, matchKeyColumnsPerFile, storageConfig, nullValueConfig, mainFile]);

  // 导出结果
  const handleExport = useCallback(async () => {
    if (!matchResult) return;

    try {
      const response = await fetch('/api/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          matchResult,
          exportConfig: { mode: 'full', preserveFormat: true, includeMatchLog: true, includeUnmatchedList: true },
          mainFileConfig: { selectedColumns: selectedMainColumns },
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        setError(result.error || '导出失败');
        return;
      }

      if (result.files?.mainFile) {
        downloadBase64File(result.files.mainFile, '匹配结果.xlsx');
      }
      if (result.files?.logFile) {
        downloadBase64File(result.files.logFile, '匹配日志.xlsx');
      }
      if (result.files?.unmatchedFile) {
        downloadBase64File(result.files.unmatchedFile, '未匹配清单.xlsx');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : '导出失败');
    }
  }, [matchResult, selectedMainColumns]);

  // Base64下载辅助函数
  const downloadBase64File = (base64: string, filename: string) => {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    const blob = new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  // 删除匹配文件
  const handleRemoveMatchFile = (id: string) => {
    setMatchSheetDataList(prev => prev.filter(item => item.id !== id));
    setSelectedMatchColumns(prev => {
      const newMap = { ...prev };
      delete newMap[id];
      return newMap;
    });
    setMatchKeyColumnsPerFile(prev => {
      const newMap = { ...prev };
      delete newMap[id];
      return newMap;
    });
    if (activeFileId === id) {
      setActiveFileId(matchSheetDataList[0]?.id || null);
    }
  };

  // 切换匹配列选择
  const toggleMatchKeyColumn = (colName: string) => {
    setMatchKeyColumns(prev =>
      prev.includes(colName)
        ? prev.filter(c => c !== colName)
        : [...prev, colName]
    );
  };

  // 切换单个匹配文件的匹配列选择
  const toggleMatchKeyColumnForFile = (fileId: string, colName: string) => {
    setMatchKeyColumnsPerFile(prev => {
      const current = prev[fileId] || [];
      return {
        ...prev,
        [fileId]: current.includes(colName)
          ? current.filter(c => c !== colName)
          : [...current, colName]
      };
    });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* 顶部标题栏 */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 sticky top-0 z-10 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-500 flex items-center justify-center shadow-md">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">VLOOKUP 批量匹配工具</h1>
              <p className="text-sm text-slate-500">一键匹配多表数据，无需编辑公式</p>
            </div>
          </div>
        </div>
      </header>

      {/* 步骤指示器 */}
      <div className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            {STEPS.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className="flex items-center gap-3">
                  <div
                    className={cn(
                      'w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all',
                      currentStep >= step.id
                        ? 'bg-blue-500 text-white shadow-md'
                        : 'bg-slate-200 text-slate-400'
                    )}
                  >
                    {currentStep > step.id ? (
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    ) : (
                      step.id
                    )}
                  </div>
                  <div>
                    <p className={cn(
                      'font-medium text-sm',
                      currentStep >= step.id ? 'text-slate-900' : 'text-slate-400'
                    )}>
                      {step.title}
                    </p>
                    <p className="text-xs text-slate-500">{step.description}</p>
                  </div>
                </div>
                {index < STEPS.length - 1 && (
                  <div className={cn(
                    'w-24 h-1 mx-4 rounded',
                    currentStep > step.id ? 'bg-blue-500' : 'bg-slate-200'
                  )} />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 错误提示 */}
      {error && (
        <div className="max-w-7xl mx-auto px-6 py-3">
          <Alert variant="destructive" className="bg-red-50 border-red-200">
            <AlertDescription className="flex items-center justify-between">
              <span className="text-red-700">{error}</span>
              <Button variant="outline" size="sm" onClick={() => setError(null)} className="border-red-200 text-red-700 hover:bg-red-100">
                关闭
              </Button>
            </AlertDescription>
          </Alert>
        </div>
      )}

      {/* 主内容区 - 左右分栏 */}
      <main className="max-w-7xl mx-auto px-6 py-6">
        <div className="grid grid-cols-12 gap-6">
          {/* 左侧配置面板 */}
          <div className="col-span-7 space-y-6">
            {/* 主文件上传 */}
            <Card className="border-2 border-dashed border-slate-300 hover:border-blue-400 transition-all">
              <CardContent className="p-6">
                {!mainSheetData ? (
                  <div className="text-center">
                    <input
                      type="file"
                      accept=".xls,.xlsx"
                      onChange={(e) => e.target.files?.[0] && handleMainFileUpload(e.target.files[0])}
                      className="hidden"
                      id="main-file-upload"
                      disabled={isProcessing}
                    />
                    <label htmlFor="main-file-upload" className="cursor-pointer block">
                      <div className="w-16 h-16 mx-auto rounded-2xl bg-blue-50 flex items-center justify-center mb-4">
                        <svg className="w-8 h-8 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                        </svg>
                      </div>
                      <p className="text-lg font-semibold text-slate-700">上传主文件（基准表）</p>
                      <p className="text-sm text-slate-500 mt-2">支持 .xls / .xlsx 格式</p>
                    </label>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center">
                        <svg className="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900">{mainFile?.name}</p>
                        <p className="text-sm text-slate-500">{mainSheetData.rowCount}行 × {mainSheetData.columnCount}列</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => { setMainFile(null); setMainSheetData(null); setMatchResult(null); setMatchKeyColumns([]); }}>
                      更换文件
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* 主文件配置 */}
            {mainSheetData && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">主文件配置</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* 匹配关键字改为多选 */}
                  <div>
                    <Label className="text-sm font-medium text-blue-600 mb-2 block">
                      匹配关键字列（多选）
                      {matchKeyColumns.length > 0 && (
                        <Badge variant="secondary" className="ml-2 bg-blue-100 text-blue-700">
                          已选 {matchKeyColumns.length} 列
                        </Badge>
                      )}
                    </Label>
                    <p className="text-xs text-slate-500 mb-2">选择多列时，需所有选中列都相同才能匹配成功</p>
                    <ScrollArea className="h-28 rounded-md border border-slate-200 bg-white p-2">
                      <div className="flex flex-wrap gap-2">
                        {mainSheetData.columnInfo.map((col: ColumnInfo) => (
                          <div
                            key={col.name}
                            className={cn(
                              'flex items-center gap-1.5 px-2.5 py-1 rounded-md cursor-pointer transition-all text-sm',
                              matchKeyColumns.includes(col.name)
                                ? 'bg-blue-100 text-blue-700 border border-blue-300'
                                : 'bg-slate-50 hover:bg-slate-100 border border-slate-200'
                            )}
                            onClick={() => toggleMatchKeyColumn(col.name)}
                          >
                            <Checkbox checked={matchKeyColumns.includes(col.name)} className="h-3.5 w-3.5" />
                            <span>{col.name}</span>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>

                  <div>
                    <Label className="text-sm font-medium mb-2 block">保留列（可选，默认全部）</Label>
                    <ScrollArea className="h-24 rounded-md border border-slate-200 bg-white p-2">
                      <div className="flex flex-wrap gap-2">
                        {mainSheetData.columnInfo.map((col: ColumnInfo) => (
                          <div
                            key={col.name}
                            className={cn(
                              'flex items-center gap-1.5 px-2.5 py-1 rounded-md cursor-pointer transition-all text-sm',
                              selectedMainColumns.includes(col.name)
                                ? 'bg-blue-100 text-blue-700 border border-blue-200'
                                : 'bg-slate-50 hover:bg-slate-100 border border-slate-200'
                            )}
                            onClick={() => {
                              setSelectedMainColumns(prev =>
                                prev.includes(col.name)
                                  ? prev.filter(c => c !== col.name)
                                  : [...prev, col.name]
                              );
                            }}
                          >
                            <Checkbox checked={selectedMainColumns.includes(col.name)} className="h-3.5 w-3.5" />
                            <span>{col.name}</span>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* 匹配文件上传 */}
            {mainSheetData && (
              <Card className="border-2 border-dashed border-slate-300 hover:border-emerald-400 transition-all">
                <CardContent className="p-6">
                  <input
                    type="file"
                    accept=".xls,.xlsx"
                    multiple
                    onChange={(e) => e.target.files && handleMatchFilesUpload(e.target.files)}
                    className="hidden"
                    id="match-files-upload"
                    disabled={isProcessing}
                  />
                  <label htmlFor="match-files-upload" className="cursor-pointer block text-center">
                    <div className="w-14 h-14 mx-auto rounded-xl bg-emerald-50 flex items-center justify-center mb-3">
                      <svg className="w-7 h-7 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                      </svg>
                    </div>
                    <p className="text-base font-semibold text-slate-700">添加匹配文件（辅表）</p>
                    <p className="text-sm text-slate-500 mt-1">可多选批量导入</p>
                  </label>
                </CardContent>
              </Card>
            )}

            {/* 已添加的匹配文件列表 */}
            {matchSheetDataList.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">匹配文件列表</CardTitle>
                    <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                      {matchSheetDataList.length} 个文件
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <Tabs value={activeFileId || ''} onValueChange={setActiveFileId}>
                    <TabsList className="w-full bg-slate-100 mb-3">
                      {matchSheetDataList.map((item) => (
                        <TabsTrigger
                          key={item.id}
                          value={item.id}
                          className="flex-1 data-[state=active]:bg-white data-[state=active]:shadow-sm"
                        >
                          <span className="truncate max-w-[120px]">{item.file.name}</span>
                        </TabsTrigger>
                      ))}
                    </TabsList>

                    {matchSheetDataList.map((item) => (
                      <TabsContent key={item.id} value={item.id}>
                        <div className="flex items-center justify-between mb-3 p-3 bg-slate-50 rounded-lg">
                          <div className="flex items-center gap-2">
                            <div className="w-10 h-10 rounded bg-emerald-100 flex items-center justify-center">
                              <svg className="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                              </svg>
                            </div>
                            <div>
                              <p className="font-medium text-slate-900">{item.file.name}</p>
                              <p className="text-xs text-slate-500">{item.data.rowCount}行 × {item.data.columnCount}列</p>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-red-500 hover:text-red-700 hover:bg-red-50"
                            onClick={() => handleRemoveMatchFile(item.id)}
                          >
                            删除
                          </Button>
                        </div>

                        {/* 匹配关键字列配置（每个文件可独立配置） */}
                        <div className="mb-3">
                          <Label className="text-sm font-medium text-emerald-600 mb-2 block">
                            匹配关键字列
                            {(matchKeyColumnsPerFile[item.id]?.length || 0) > 0 && (
                              <Badge variant="secondary" className="ml-2 bg-emerald-100 text-emerald-700">
                                已选 {matchKeyColumnsPerFile[item.id]?.length || 0} 列
                              </Badge>
                            )}
                          </Label>
                          <p className="text-xs text-slate-500 mb-2">可覆盖主文件设置，不选则使用主文件匹配列</p>
                          <ScrollArea className="h-24 rounded-md border border-slate-200 bg-white p-2">
                            <div className="flex flex-wrap gap-2">
                              {item.data.columnInfo.map((col: ColumnInfo) => {
                                const isSelected = matchKeyColumnsPerFile[item.id]?.includes(col.name) || false;
                                const isInMainFile = mainSheetData?.headers.includes(col.name);
                                return (
                                  <div
                                    key={col.name}
                                    className={cn(
                                      'flex items-center gap-1.5 px-2.5 py-1 rounded-md cursor-pointer transition-all text-sm',
                                      isSelected
                                        ? 'bg-emerald-100 text-emerald-700 border border-emerald-300'
                                        : 'bg-slate-50 hover:bg-slate-100 border border-slate-200'
                                    )}
                                    onClick={() => toggleMatchKeyColumnForFile(item.id, col.name)}
                                  >
                                    <Checkbox checked={isSelected} className="h-3.5 w-3.5" />
                                    <span>{col.name}</span>
                                    {isInMainFile && (
                                      <Badge variant="outline" className="text-xs h-4 bg-blue-50 text-blue-600 border-blue-200">
                                        同名
                                      </Badge>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </ScrollArea>
                        </div>

                        <Label className="text-sm font-medium mb-2 block">提取列</Label>
                        <ScrollArea className="h-24 rounded-md border border-slate-200 bg-white p-2">
                          <div className="flex flex-wrap gap-2">
                            {item.data.columnInfo.map((col: ColumnInfo) => {
                              const isSelected = selectedMatchColumns[item.id]?.includes(col.name) || false;
                              const isSameName = mainSheetData?.headers.includes(col.name);
                              return (
                                <div
                                  key={col.name}
                                  className={cn(
                                    'flex items-center gap-1.5 px-2.5 py-1 rounded-md cursor-pointer transition-all text-sm',
                                    isSelected
                                      ? 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                                      : 'bg-slate-50 hover:bg-slate-100 border border-slate-200'
                                  )}
                                  onClick={() => {
                                    setSelectedMatchColumns(prev => {
                                      const current = prev[item.id] || [];
                                      return {
                                        ...prev,
                                        [item.id]: current.includes(col.name)
                                          ? current.filter(c => c !== col.name)
                                          : [...current, col.name]
                                      };
                                    });
                                  }}
                                >
                                  <Checkbox checked={isSelected} className="h-3.5 w-3.5" />
                                  <span>{col.name}</span>
                                  {isSameName && (
                                    <Badge variant="outline" className="text-xs h-4 bg-blue-50 text-blue-600 border-blue-200">
                                      同名
                                    </Badge>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </ScrollArea>
                      </TabsContent>
                    ))}
                  </Tabs>
                </CardContent>
              </Card>
            )}
          </div>

          {/* 右侧配置与预览面板 */}
          <div className="col-span-5 space-y-6">
            {/* 存储规则配置 */}
            {matchSheetDataList.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">存储规则配置</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-xs text-slate-500 mb-1.5 block">存储模式</Label>
                    <Select
                      value={storageConfig.defaultRule.mode}
                      onValueChange={(v) => setStorageConfig(prev => ({
                        ...prev,
                        defaultRule: { ...prev.defaultRule, mode: v as 'same-name-fill' | 'force-new-column' }
                      }))}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="same-name-fill">同名原位回填</SelectItem>
                        <SelectItem value="force-new-column">全部新建列</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500 mb-1.5 block">无匹配时填充值</Label>
                    <Input
                      value={nullValueConfig.globalFill}
                      onChange={(e) => setNullValueConfig(prev => ({ ...prev, globalFill: e.target.value }))}
                      placeholder="#N/A"
                      className="bg-white"
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* 执行操作 */}
            {mainSheetData && matchSheetDataList.length > 0 && matchKeyColumns.length > 0 && (
              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                <CardContent className="p-6">
                  <div className="text-center mb-4">
                    <p className="text-sm text-slate-600 mb-2">已配置完成，点击执行匹配</p>
                    <div className="flex gap-2 justify-center text-xs text-slate-500">
                      <span>主表: {mainSheetData.rowCount}行</span>
                      <span>•</span>
                      <span>辅表: {matchSheetDataList.length}个</span>
                      <span>•</span>
                      <span>关键字: {matchKeyColumns.join(' + ')}</span>
                    </div>
                  </div>
                  <Button
                    size="lg"
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white shadow-md"
                    disabled={isProcessing}
                    onClick={handleExecuteMatch}
                  >
                    {isProcessing ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>正在匹配...</span>
                      </div>
                    ) : (
                      <span className="flex items-center gap-2">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                        执行匹配
                      </span>
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* 匹配结果 */}
            {matchResult && (
              <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 border-emerald-200">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <svg className="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    匹配完成
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-3 gap-3">
                    <div className="text-center p-3 bg-white rounded-lg shadow-sm">
                      <p className="text-2xl font-bold text-slate-900">{matchResult.totalRows}</p>
                      <p className="text-xs text-slate-500">总行数</p>
                    </div>
                    <div className="text-center p-3 bg-emerald-50 rounded-lg shadow-sm">
                      <p className="text-2xl font-bold text-emerald-700">{matchResult.matchedCount}</p>
                      <p className="text-xs text-emerald-600">已匹配</p>
                    </div>
                    <div className="text-center p-3 bg-red-50 rounded-lg shadow-sm">
                      <p className="text-2xl font-bold text-red-700">{matchResult.unmatchedCount}</p>
                      <p className="text-xs text-red-600">未匹配</p>
                    </div>
                  </div>

                  {matchResult.outputData.length > 0 && (
                    <div>
                      <Label className="text-xs text-slate-500 mb-2 block">数据预览（前5行）</Label>
                      <ScrollArea className="h-32 rounded-md border border-slate-200 bg-white">
                        <div className="p-2">
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="border-b border-slate-200">
                                {matchResult.outputHeaders.slice(0, 5).map(h => (
                                  <th key={h} className="p-1.5 font-medium text-left text-slate-700 bg-slate-50">{h}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {matchResult.outputData.slice(0, 5).map((row, i) => (
                                <tr key={i} className="border-b border-slate-100">
                                  {matchResult.outputHeaders.slice(0, 5).map(h => (
                                    <td key={h} className="p-1.5 text-slate-600 truncate">{String(row[h] || '').substring(0, 20)}</td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </ScrollArea>
                    </div>
                  )}

                  <Button
                    size="lg"
                    className="w-full bg-emerald-500 hover:bg-emerald-600 text-white shadow-md"
                    onClick={handleExport}
                  >
                    <span className="flex items-center gap-2">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                      导出结果
                    </span>
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      {/* 进度显示 */}
      {isProcessing && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-20">
          <Card className="w-80 shadow-xl">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-blue-100 flex items-center justify-center">
                <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
              </div>
              <p className="font-semibold text-slate-900 mb-2">正在处理</p>
              <p className="text-sm text-slate-500">请稍候...</p>
              <Progress value={50} className="mt-4" />
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}