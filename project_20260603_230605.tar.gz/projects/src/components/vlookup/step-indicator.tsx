'use client';

import type { CurrentStep } from '@/lib/types';
import { cn } from '@/lib/utils';

interface Step {
  key: CurrentStep;
  label: string;
}

interface StepIndicatorProps {
  steps: Step[];
  currentStep: CurrentStep;
  onStepClick: (step: CurrentStep) => void;
}

export function StepIndicator({ steps, currentStep, onStepClick }: StepIndicatorProps) {
  const currentIndex = steps.findIndex(s => s.key === currentStep);

  return (
    <div className="flex items-center justify-center gap-2">
      {steps.map((step, index) => {
        const isActive = step.key === currentStep;
        const isCompleted = index < currentIndex;

        return (
          <div key={step.key} className="flex items-center">
            <button
              onClick={() => onStepClick(step.key)}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-lg transition-all',
                'focus:outline-none focus:ring-2 focus:ring-blue-500',
                isActive && 'bg-blue-500 text-white',
                isCompleted && 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200',
                !isActive && !isCompleted && 'bg-slate-100 text-slate-500 hover:bg-slate-200'
              )}
            >
              {/* 状态图标 */}
              <span
                className={cn(
                  'w-6 h-6 rounded-full flex items-center justify-center text-sm font-medium',
                  isActive && 'bg-white text-blue-500',
                  isCompleted && 'bg-emerald-500 text-white',
                  !isActive && !isCompleted && 'bg-slate-300 text-slate-600'
                )}
              >
                {isCompleted ? '✓' : index + 1}
              </span>
              <span className="font-medium">{step.label}</span>
            </button>

            {/* 连接线 */}
            {index < steps.length - 1 && (
              <div
                className={cn(
                  'w-8 h-1 mx-2 rounded',
                  index < currentIndex ? 'bg-emerald-500' : 'bg-slate-200'
                )}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}