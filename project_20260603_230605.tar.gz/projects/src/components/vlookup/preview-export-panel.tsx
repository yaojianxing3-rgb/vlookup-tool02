'use client';

import { useState } from 'react';
import type {
  MatchResult,
  MainFileConfig,
  MatchFileConfig,
  GlobalStorageConfig,
  NullValueConfig,
  ExportMode,
} from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface PreviewExportPanelProps {
  matchResult: MatchResult | null;
  isProcessing: boolean;
  mainFileConfig: MainFileConfig;
  matchFileConfigs: MatchFileConfig[];
  globalStorageConfig: GlobalStorageConfig;
  nullValueConfig: NullValueConfig;
  onExecuteMatch: () => Promise<void>;
}

export function PreviewExportPanel({
  matchResult,
  isProcessing,
  mainFileConfig,
  matchFileConfigs,
  globalStorageConfig,
  nullValueConfig,
  onExecuteMatch,
}: PreviewExportPanelProps) {
  const [exportMode, setExportMode] = useState<ExportMode>('full');
  const [includeMatchLog, setIncludeMatchLog] = useState(true);
  const [includeUnmatchedList, setIncludeUnmatchedList] = useState(true);

  // 执行匹配
  const handleExecute = async () => {
    await onExecuteMatch();
  };

  // 导出文件
  const handleExport = async () => {
    if (!matchResult) return;

    try {
      const response = await fetch('/api/export', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          matchResult,
          exportConfig: {
            mode: exportMode,
            preserveFormat: true,
            includeMatchLog,
            includeUnmatchedList,
          },
          mainFileConfig,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        alert(result.error || '导出失败');
        return;
      }

      // 下载文件
      if (result.files?.mainFile) {
        downloadBase64File(result.files.mainFile, '匹配结果.xlsx');
      }
      if (result.files?.logFile) {
        downloadBase64File(result.files.logFile, '匹配日志.xlsx');
      }
      if (result.files?.unmatchedFile) {
        downloadBase64File(result.files.unmatchedFile, '未匹配清单.xlsx');
      }
    } catch (err) {
      alert(err instanceof Error ? err.message : '导出失败');
    }
  };

  // Base64 文件下载辅助函数
  const downloadBase64File = (base64: string, filename: string) => {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    const blob = new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Card className="border-slate-200">
      <CardHeader className="bg-slate-50 border-b border-slate-200">
        <CardTitle className="text-lg flex items-center gap-2">
          <span className="w-8 h-8 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-medium">
            4
          </span>
          预览与导出
        </CardTitle>
        <p className="text-sm text-slate-500 mt-1">
          预览匹配结果并导出最终文件
        </p>
      </CardHeader>

      <CardContent className="p-6 space-y-6">
        {/* 执行匹配按钮 */}
        {!matchResult && (
          <div className="space-y-4">
            <div className="text-center py-8">
              <Button
                size="lg"
                onClick={handleExecute}
                disabled={isProcessing}
                className="w-full max-w-xs"
              >
                {isProcessing ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    正在执行匹配...
                  </div>
                ) : (
                  '执行批量匹配'
                )}
              </Button>
              
              {isProcessing && (
                <Progress value={50} className="mt-4 w-full max-w-xs mx-auto" />
              )}
            </div>

            {/* 配置摘要 */}
            <Separator />
            
            <div className="bg-slate-100 rounded-lg p-4 space-y-2 text-sm">
              <p className="font-medium">配置摘要：</p>
              <div className="flex items-center gap-2">
                <Badge variant="outline">主文件</Badge>
                <span className="text-slate-600">
                  {mainFileConfig.file?.name || '未选择'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline">匹配文件</Badge>
                <span className="text-slate-600">
                  {matchFileConfigs.filter(f => f.enabled).length} 个
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline">存储模式</Badge>
                <span className="text-slate-600">
                  {globalStorageConfig.defaultRule.mode === 'same-name-fill'
                    ? '同名原位回填'
                    : '全部新建列'}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* 匹配结果统计 */}
        {matchResult && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-slate-100 rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-slate-900">
                  {matchResult.totalRows}
                </p>
                <p className="text-sm text-slate-500">总行数</p>
              </div>
              <div className="bg-emerald-100 rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-emerald-700">
                  {matchResult.matchedCount}
                </p>
                <p className="text-sm text-emerald-600">已匹配</p>
              </div>
              <div className="bg-red-100 rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-red-700">
                  {matchResult.unmatchedCount}
                </p>
                <p className="text-sm text-red-600">未匹配</p>
              </div>
            </div>

            {/* 预览数据 */}
            {matchResult.previewRows.length > 0 && (
              <div className="space-y-2">
                <Label className="font-medium">数据预览（前50行）</Label>
                <ScrollArea className="h-48 rounded-md border border-slate-200">
                  <div className="p-4">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-slate-200">
                          {matchResult.outputHeaders.slice(0, 6).map((header) => (
                            <th key={header} className="text-left p-2 font-medium">
                              {header}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {matchResult.outputData.slice(0, 10).map((row, idx) => (
                          <tr key={idx} className="border-b border-slate-100">
                            {matchResult.outputHeaders.slice(0, 6).map((header) => (
                              <td key={header} className="p-2 text-slate-600">
                                {String(row[header] || '').substring(0, 20)}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </ScrollArea>
              </div>
            )}

            <Separator />

            {/* 导出配置 */}
            <div className="space-y-4">
              <Label className="font-medium">导出配置</Label>
              
              {/* 导出模式选择 */}
              <div className="grid grid-cols-1 gap-2">
                {[
                  { value: 'full', label: '完整导出', desc: '主勾选列 + 全部新增匹配列' },
                  { value: 'main-only', label: '仅导出主勾选列', desc: '舍弃新增匹配字段' },
                  { value: 'match-only', label: '单独导出匹配字段', desc: '仅导出本次新增的匹配列' },
                ].map((option) => (
                  <div
                    key={option.value}
                    className={cn(
                      'p-3 rounded-lg border-2 cursor-pointer transition-all',
                      exportMode === option.value
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-slate-200 hover:border-slate-300'
                    )}
                    onClick={() => setExportMode(option.value as ExportMode)}
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className={cn(
                          'w-4 h-4 rounded-full',
                          exportMode === option.value ? 'bg-blue-500' : 'bg-slate-300'
                        )}
                      />
                      <span className="font-medium">{option.label}</span>
                    </div>
                    <p className="text-sm text-slate-500 mt-1 ml-6">{option.desc}</p>
                  </div>
                ))}
              </div>

              {/* 附加导出选项 */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={includeMatchLog}
                    onCheckedChange={(checked) => setIncludeMatchLog(checked as boolean)}
                  />
                  <Label className="text-sm">包含匹配日志Excel</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={includeUnmatchedList}
                    onCheckedChange={(checked) => setIncludeUnmatchedList(checked as boolean)}
                  />
                  <Label className="text-sm">包含未匹配主键清单</Label>
                </div>
              </div>
            </div>

            {/* 导出按钮 */}
            <div className="flex gap-3">
              <Button
                size="lg"
                onClick={handleExport}
                className="flex-1 bg-emerald-500 hover:bg-emerald-600"
              >
                导出结果
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={() => {
                  // 重置匹配结果
                }}
              >
                重新匹配
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}