'use client';

import { useState, useCallback, useEffect } from 'react';
import type { ProjectConfig, MainFileConfig, MatchFileConfig, GlobalStorageConfig, NullValueConfig } from '@/lib/types';

const STORAGE_KEY = 'vlookup-configs';

/** 配置存档 Hook */
export function useConfigStorage() {
  const [savedConfigs, setSavedConfigs] = useState<ProjectConfig[]>([]);

  // 从 localStorage 加载配置列表
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const configs = JSON.parse(stored) as ProjectConfig[];
        setSavedConfigs(configs);
      }
    } catch (error) {
      console.warn('加载配置失败:', error);
    }
  }, []);

  // 保存配置
  const saveConfig = useCallback(
    (
      name: string,
      mainFileConfig: MainFileConfig,
      matchFileConfigs: MatchFileConfig[],
      globalStorageConfig: GlobalStorageConfig,
      nullValueConfig: NullValueConfig
    ): ProjectConfig => {
      const now = Date.now();
      const config: ProjectConfig = {
        id: `config-${now}-${Math.random().toString(36).substring(2, 9)}`,
        name,
        createdAt: now,
        updatedAt: now,
        mainFileConfig: {
          ...mainFileConfig,
          // 不保存 File 对象
          file: null,
        },
        matchFileConfigs: matchFileConfigs.map(c => ({
          ...c,
          // 不保存 File 对象
          file: {
            ...c.file,
            file: null as unknown as File,
          },
        })),
        globalStorageConfig,
        nullValueConfig,
      };

      const newConfigs = [...savedConfigs, config];
      setSavedConfigs(newConfigs);
      
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newConfigs));
      } catch (error) {
        console.warn('保存配置失败:', error);
      }

      return config;
    },
    [savedConfigs]
  );

  // 加载配置
  const loadConfig = useCallback(
    (configId: string): ProjectConfig | null => {
      const config = savedConfigs.find(c => c.id === configId);
      return config || null;
    },
    [savedConfigs]
  );

  // 删除配置
  const deleteConfig = useCallback(
    (configId: string) => {
      const newConfigs = savedConfigs.filter(c => c.id !== configId);
      setSavedConfigs(newConfigs);
      
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newConfigs));
      } catch (error) {
        console.warn('删除配置失败:', error);
      }
    },
    [savedConfigs]
  );

  // 更新配置名称
  const renameConfig = useCallback(
    (configId: string, newName: string) => {
      const newConfigs = savedConfigs.map(c => 
        c.id === configId 
          ? { ...c, name: newName, updatedAt: Date.now() }
          : c
      );
      setSavedConfigs(newConfigs);
      
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newConfigs));
      } catch (error) {
        console.warn('更新配置名称失败:', error);
      }
    },
    [savedConfigs]
  );

  // 导出配置为JSON文件
  const exportConfigAsJson = useCallback(
    (configId: string) => {
      const config = savedConfigs.find(c => c.id === configId);
      if (!config) return;

      const jsonStr = JSON.stringify(config, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${config.name}.json`;
      a.click();
      URL.revokeObjectURL(url);
    },
    [savedConfigs]
  );

  // 从JSON文件导入配置
  const importConfigFromJson = useCallback(
    async (file: File): Promise<ProjectConfig | null> => {
      try {
        const text = await file.text();
        const config = JSON.parse(text) as ProjectConfig;
        
        // 验证配置结构
        if (!config.id || !config.name || !config.createdAt) {
          throw new Error('配置文件格式不正确');
        }

        // 更新ID和时间为新值
        const now = Date.now();
        const newConfig: ProjectConfig = {
          ...config,
          id: `config-${now}-${Math.random().toString(36).substring(2, 9)}`,
          createdAt: now,
          updatedAt: now,
        };

        const newConfigs = [...savedConfigs, newConfig];
        setSavedConfigs(newConfigs);
        
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(newConfigs));
        } catch (error) {
          console.warn('保存导入配置失败:', error);
        }

        return newConfig;
      } catch (error) {
        console.warn('导入配置失败:', error);
        return null;
      }
    },
    [savedConfigs]
  );

  return {
    savedConfigs,
    saveConfig,
    loadConfig,
    deleteConfig,
    renameConfig,
    exportConfigAsJson,
    importConfigFromJson,
  };
}