// Excel 文件处理工具库
import * as XLSX from 'xlsx';
import type {
FileInfo,
SheetData,
ColumnInfo,
MainFileConfig,
MatchFileConfig,
GlobalStorageConfig,
NullValueConfig,
MatchResult,
MatchResultRow,
MatchLogRecord,
UnmatchedRecord,
} from './types';

/** 生成唯一ID */
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

/** 解析Excel文件 */
export async function parseExcelFile(
  file: File,
  headerRow: number = 1
): Promise<{ fileInfo: FileInfo; sheetData: SheetData } | { error: string }> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });

    const sheetNames = workbook.SheetNames;
    if (sheetNames.length === 0) {
      return { error: '文件为空，没有任何工作表' };
    }

    // 默认使用第一个工作表
    const sheetName = sheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' }) as unknown[][];

    if (jsonData.length === 0) {
      return { error: '工作表为空' };
    }

    // 处理表头行号
    const headerRowIndex = headerRow - 1;
    if (headerRowIndex >= jsonData.length) {
      return { error: `表头行号 ${headerRow} 超出数据范围` };
    }

    const headers = (jsonData[headerRowIndex] as (string | number)[]).map(h =>String(h || '').trim());
    const dataRows = jsonData.slice(headerRowIndex + 1);

    // 构建列信息
    const columnInfo: ColumnInfo[] = headers.map((name, index) => {
      const sampleData = dataRows.slice(0, 10).map(row => {
        const value = row[index];
        return value !== undefined && value !== null ? String(value) : '';
      });

      // 检测数据类型
      const nonEmptySamples = sampleData.filter(s => s !== '');
      let dataType: ColumnInfo['dataType'] = 'mixed';
      if (nonEmptySamples.length > 0) {
        const allNumbers = nonEmptySamples.every(s =>!isNaN(Number(s)));
        if (allNumbers) dataType = 'number';
        else dataType = 'text';
      }

      return {
        name,
        index,
        sampleData,
        isSelected: false,
        dataType,
      };
    });

    // 构建行数据
    const rows: Record<string, string | number>[] = dataRows.map(row => {
      const rowData: Record<string, string | number> = {};
      headers.forEach((header, idx) => {
        const value = row[idx];
        rowData[header] = value !== undefined && value !== null ? String(value) : '';
      });
      return rowData;
    });

    const fileInfo: FileInfo = {
      id: generateId(),
      name: file.name,
      file,
      sheetNames,
      selectedSheet: sheetName,
      headerRow,
      rowCount: rows.length,
      columnCount: headers.length,
      isValid: true,
    };

    const sheetData: SheetData = {
      headers,
      rows,
      columnInfo,
      rowCount: rows.length,
      columnCount: headers.length,
    };

    return { fileInfo, sheetData };
  } catch (error) {
    return { error: `文件解析失败: ${error instanceof Error ? error.message : '未知错误'}` };
  }
}

/** 预处理关键字值 */
export function preprocessKeyValue(value: string | number): string {
  let str = String(value);
  // 清除首尾空格
  str = str.trim();
  // 清除常见隐形特殊字符
  str = str.replace(/[\u00A0\u2000-\u200B\u202F\u205F\u3000]/g, '');
  // 统一换行符
  str = str.replace(/\r\n|\r|\n/g, '');
  return str;
}

/** 构建匹配键 */
export function buildMatchKey(
  row: Record<string, string | number>,
  keyColumns: string[],
  preprocess: boolean = true
): string {
  const values = keyColumns.map(col => {
    const value = row[col] ?? '';
    return preprocess ? preprocessKeyValue(value) : String(value);
  });
  return values.join('|||'); // 使用特殊分隔符避免冲突
}

/** 执行VLOOKUP/哈希匹配 */
export async function executeMatch(
  mainSheetData: SheetData,
  matchFileData: Map<string, SheetData>,
  mainFileConfig: MainFileConfig,
  matchFileConfigs: MatchFileConfig[],
  globalStorageConfig: GlobalStorageConfig,
  nullValueConfig: NullValueConfig
): Promise<MatchResult> {
  const logs: MatchLogRecord[] = [];
  const unmatchedRecords: UnmatchedRecord[] = [];

  // 构建主表数据索引
  const mainRows = mainSheetData.rows;
  const mainHeaders = mainSheetData.headers;

  // 为每个匹配文件构建哈希索引（大于2万行时使用哈希）
  const matchIndices = new Map<string, Map<string, Record<string, string | number>[]>>();

  for (const config of matchFileConfigs) {
    if (!config.enabled) continue;

    const sheetData = matchFileData.get(config.id);
    if (!sheetData) continue;

    const useHash = sheetData.rows.length > 20000;
    const index = new Map<string, Record<string, string | number>[]>();

    for (const row of sheetData.rows) {
      const key = buildMatchKey(row, config.matchKeyColumns || mainFileConfig.matchKeyColumns, mainFileConfig.preprocessKey);
      if (!index.has(key)) {
        index.set(key, []);
      }
      index.get(key)!.push(row);
    }

    matchIndices.set(config.id, index);
  }

  // 执行匹配
  const outputHeaders: string[] = [...mainFileConfig.selectedColumns];
  const additionalHeaders: string[] = [];

  // 首先确定所有需要新增的列
  for (const config of matchFileConfigs) {
    if (!config.enabled) continue;

    const sheetData = matchFileData.get(config.id);
    if (!sheetData) continue;

    const storageRule = config.storageRuleOverride || globalStorageConfig.defaultRule;

    for (const col of config.selectedColumns) {
      const isSameName = mainHeaders.includes(col);

      if (storageRule.mode === 'force-new-column' || !isSameName) {
        // 新建列
        let newColName = col;
        if (storageRule.newColumnNaming === 'filename-column') {
          newColName = `${config.file.name}_${col}`;
        } else if (storageRule.newColumnNaming === 'prefix-column' && storageRule.customPrefix) {
          newColName = `${storageRule.customPrefix}_${col}`;
        } else if (storageRule.newColumnNaming === 'custom' && storageRule.customColumnNames?.[col]) {
          newColName = storageRule.customColumnNames[col];
        }
        additionalHeaders.push(newColName);
      }
    }
  }

  // 合并输出列
  outputHeaders.push(...additionalHeaders);

  // 匹配每一行
  const outputData: Record<string, string | number>[] = [];
  const previewRows: MatchResultRow[] = [];
  let matchedCount = 0;
  let unmatchedCount = 0;

  for (let rowIndex = 0; rowIndex < mainRows.length; rowIndex++) {
    const mainRow = mainRows[rowIndex];
    const matchKey = buildMatchKey(mainRow, mainFileConfig.matchKeyColumns, mainFileConfig.preprocessKey);

    // 初始化输出行
    const outputRow: Record<string, string | number> = {};
    for (const col of mainFileConfig.selectedColumns) {
      outputRow[col] = mainRow[col] ?? '';
    }

    // 初始化新增列
    for (const col of additionalHeaders) {
      outputRow[col] = nullValueConfig.globalFill || '#N/A';
    }

    const matchedData: Record<string, string | number> = {};
    const matchSources: Record<string, { fileId: string; fileName: string; success: boolean }> = {};
    const attemptedFiles: string[] = [];

    // 逐文件匹配
    for (const config of matchFileConfigs) {
      if (!config.enabled) continue;

      const index = matchIndices.get(config.id);
      if (!index) continue;

      const matchedRows = index.get(matchKey);
      attemptedFiles.push(config.file.name);

      if (!matchedRows || matchedRows.length === 0) {
        matchSources[config.id] = {
          fileId: config.id,
          fileName: config.file.name,
          success: false,
        };
        continue;
      }

      matchSources[config.id] = {
        fileId: config.id,
        fileName: config.file.name,
        success: true,
      };

      // 根据重复主键处理规则选择数据
      let sourceRow: Record<string, string | number>;
      if (globalStorageConfig.duplicateKeyHandling === 'first-match') {
        sourceRow = matchedRows[0];
      } else if (globalStorageConfig.duplicateKeyHandling === 'last-match') {
        sourceRow = matchedRows[matchedRows.length - 1];
      } else {
        // concat-all: 多值拼接
        sourceRow = {};
        for (const row of matchedRows) {
          for (const col of config.selectedColumns) {
            const value = row[col];
            if (sourceRow[col]) {
              sourceRow[col] = `${sourceRow[col]},${value}`;
            } else {
              sourceRow[col] = value;
            }
          }
        }
      }

      const storageRule = config.storageRuleOverride || globalStorageConfig.defaultRule;
      const sheetData = matchFileData.get(config.id);

      for (const col of config.selectedColumns) {
        const value = sourceRow[col];
        const isSameName = mainHeaders.includes(col);

        // 记录日志
        logs.push({
          mainRowIndex: rowIndex,
          matchKey,
          sourceFile: config.file.name,
          sourceColumn: col,
          matchedValue: value ?? '',
          success: true,
          timestamp: Date.now(),
        });

        matchedData[col] = value ?? '';

        if (storageRule.mode === 'same-name-fill' && isSameName) {
          // 同名列回填
          const existingValue = outputRow[col];
          const fillMode = storageRule.sameNameFillMode || 'fill-blank-only';

          if (fillMode === 'fill-blank-only') {
            if (existingValue === '' || existingValue === null || existingValue === undefined) {
              outputRow[col] = value ?? '';
            }
          } else if (fillMode === 'overwrite-all') {
            outputRow[col] = value ?? '';
          } else if (fillMode === 'fill-blank-preserve-main') {
            if (existingValue === '' || existingValue === null || existingValue === undefined) {
              if (value !== '' && value !== null && value !== undefined) {
                outputRow[col] = value;
              }
            }
          }
        } else {
          // 新建列
          let newColName = col;
          if (storageRule.newColumnNaming === 'filename-column') {
            newColName = `${config.file.name}_${col}`;
          } else if (storageRule.newColumnNaming === 'prefix-column' && storageRule.customPrefix) {
            newColName = `${storageRule.customPrefix}_${col}`;
          } else if (storageRule.newColumnNaming === 'custom' && storageRule.customColumnNames?.[col]) {
            newColName = storageRule.customColumnNames[col];
          }

          outputRow[newColName] = value ?? '';
        }
      }
    }

    // 检查是否成功匹配
    const hasMatch = Object.values(matchSources).some(s => s.success);
    if (hasMatch) {
      matchedCount++;
    } else {
      unmatchedCount++;
      unmatchedRecords.push({
        mainRowIndex: rowIndex,
        matchKey,
        attemptedFiles,
      });
    }

    outputData.push(outputRow);

    // 收集预览数据（前50行）
    if (rowIndex < 50) {
      previewRows.push({
        mainRowIndex: rowIndex,
        matchKey,
        matchedData,
        matchSources,
      });
    }
  }

  return {
    previewRows,
    totalRows: mainRows.length,
    matchedCount,
    unmatchedCount,
    matchLogs: logs,
    unmatchedRecords,
    outputData,
    outputHeaders,
  };
}

/** 导出Excel文件 */
export function exportToExcel(
  data: Record<string, string | number>[],
  headers: string[],
  filename: string
): Buffer {
  const worksheet = XLSX.utils.json_to_sheet(data, { header: headers });
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
  return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}

/** 导出匹配日志 */
export function exportMatchLogs(logs: MatchLogRecord[]): Buffer {
  const logData = logs.map(log => ({
    主表行号: log.mainRowIndex + 1,
    匹配键: log.matchKey,
    来源文件: log.sourceFile,
    来源列: log.sourceColumn,
    匹配值: log.matchedValue,
    状态: log.success ? '成功' : '失败',
    时间: new Date(log.timestamp).toISOString(),
  }));

  const worksheet = XLSX.utils.json_to_sheet(logData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, '匹配日志');
  return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}

/** 导出未匹配清单 */
export function exportUnmatchedList(records: UnmatchedRecord[]): Buffer {
  const data = records.map(rec => ({
    主表行号: rec.mainRowIndex + 1,
    匹配键: rec.matchKey,
    尝试匹配文件: rec.attemptedFiles.join(';'),
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, '未匹配清单');
  return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}