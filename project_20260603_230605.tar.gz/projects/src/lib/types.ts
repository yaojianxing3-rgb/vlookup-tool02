// VLOOKUP 多文件批量匹配工具核心类型定义

// ============ 文件相关类型 ============

/** Excel 文件信息 */
export interface FileInfo {
  id: string;
  name: string;
  file?: File; // 可选，避免序列化问题
  sheetNames: string[];
  selectedSheet: string;
  headerRow: number; // 表头行号，默认1
  rowCount: number;
  columnCount: number;
  isValid: boolean;
  errorMessage?: string;
}

/** Excel 列信息 */
export interface ColumnInfo {
  name: string;
  index: number;
  sampleData: string[]; // 前10行样例数据
  isSelected: boolean;
  dataType: 'text' | 'number' | 'date' | 'mixed';
}

/** Excel 表格数据 */
export interface SheetData {
  headers: string[];
  rows: Record<string, string | number>[];
  columnInfo: ColumnInfo[];
  rowCount: number;
  columnCount: number;
}

// ============ 主文件配置类型 ============

/** 主文件配置 */
export interface MainFileConfig {
  file: FileInfo | null;
  selectedColumns: string[]; // 需要保留的列
  matchKeyColumns: string[]; // 匹配关键字列（支持多列）
  headerRow: number;
  preprocessKey: boolean; // 是否预处理关键字（去空格、特殊字符）
  matchVisibleRowsOnly: boolean; // 仅匹配筛选后的可见行
}

// ============ 匹配文件配置类型 ============

/** 单个匹配文件配置 */
export interface MatchFileConfig {
  id: string;
  file: FileInfo;
  enabled: boolean; // 启用/停用
  order: number; // 排序顺序
  group?: string; // 分组名称
  selectedColumns: string[]; // 需要提取的列
  matchKeyColumns: string[]; // 匹配关键字列（可覆盖全局）
  storageRuleOverride?: StorageRule; // 单文件规则覆盖
  columnRuleOverrides?: Record<string, StorageRule>; // 单列规则覆盖
}

// ============ 存储规则类型 ============

/** 存储规则基础模式 */
export type StorageMode = 'same-name-fill' | 'force-new-column';

/** 同名列回填子选项 */
export type SameNameFillMode = 
  | 'fill-blank-only' // 仅填充主表空白单元格
  | 'overwrite-all' // 全量覆盖主表原有所有数据
  | 'fill-blank-preserve-main'; // 主表为空才填充、辅表为空不覆盖主表数据

/** 新建列命名规则 */
export type NewColumnNamingMode = 
  | 'filename-column' // 文件名_列名
  | 'prefix-column' // 自定义前缀_列名
  | 'custom'; // 手动自定义单列表头名称

/** 存储规则配置 */
export interface StorageRule {
  mode: StorageMode;
  sameNameFillMode?: SameNameFillMode;
  newColumnNaming?: NewColumnNamingMode;
  customPrefix?: string; // 自定义前缀
  customColumnNames?: Record<string, string>; // 单列自定义名称
}

/** 全局存储规则配置 */
export interface GlobalStorageConfig {
  defaultRule: StorageRule;
  duplicateKeyHandling: 'first-match' | 'last-match' | 'concat-all'; // 重复主键取值规则
  noMatchFill: string; // 无匹配时填充内容，默认 '#N/A'
}

// ============空值处理类型 ============

/** 空值处理配置 */
export interface NullValueConfig {
  globalFill: string; // 全局默认填充
  fileOverrides?: Record<string, string>; // 单文件覆盖
  columnOverrides?: Record<string, string>; // 单列覆盖
}

// ============ 配置存档类型 ============

/** 完整工程配置 */
export interface ProjectConfig {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  mainFileConfig: MainFileConfig;
  matchFileConfigs: MatchFileConfig[];
  globalStorageConfig: GlobalStorageConfig;
  nullValueConfig: NullValueConfig;
}

// ============ 导出配置类型 ============

/** 导出模式 */
export type ExportMode = 
  | 'full' // 完整导出（主勾选列 + 全部新增匹配列）
  | 'main-only' // 仅导出主勾选列
  | 'match-only'; // 单独导出本次新增匹配字段

/** 导出配置 */
export interface ExportConfig {
  mode: ExportMode;
  preserveFormat: boolean; // 保留原单元格格式
  includeMatchLog: boolean; // 包含匹配日志
  includeUnmatchedList: boolean; // 包含未匹配主键清单
}

// ============ 匹配结果类型 ============

/** 单行匹配结果 */
export interface MatchResultRow {
  mainRowIndex: number;
  matchKey: string;
  matchedData: Record<string, string | number>;
  matchSources: Record<string, { fileId: string; fileName: string; success: boolean }>;
}

/** 匹配日志记录 */
export interface MatchLogRecord {
  mainRowIndex: number;
  matchKey: string;
  sourceFile: string;
  sourceColumn: string;
  matchedValue: string | number;
  success: boolean;
  timestamp: number;
}

/** 未匹配记录 */
export interface UnmatchedRecord {
  mainRowIndex: number;
  matchKey: string;
  attemptedFiles: string[];
}

/** 完整匹配结果 */
export interface MatchResult {
  previewRows: MatchResultRow[]; // 预览行（前50行）
  totalRows: number;
  matchedCount: number;
  unmatchedCount: number;
  matchLogs: MatchLogRecord[];
  unmatchedRecords: UnmatchedRecord[];
  outputData: Record<string, string | number>[]; // 完整输出数据
  outputHeaders: string[]; // 输出列名
}

// ============ 用户界面状态类型 ============

/** 当前步骤 */
export type CurrentStep = 'main-file' | 'match-files' | 'rules' | 'preview-export';

/** 应用状态 */
export interface AppState {
  currentStep: CurrentStep;
  mainFileConfig: MainFileConfig;
  matchFileConfigs: MatchFileConfig[];
  globalStorageConfig: GlobalStorageConfig;
  nullValueConfig: NullValueConfig;
  matchResult: MatchResult | null;
  isProcessing: boolean;
  savedConfigs: ProjectConfig[];
}

// ============ API请求/响应类型 ============

/** 文件上传请求 */
export interface FileUploadRequest {
  file: File;
  headerRow?: number;
}

/** 文件解析响应 */
export interface FileParseResponse {
  success: boolean;
  fileInfo: FileInfo;
  sheetData: SheetData;
  error?: string;
}

/** 匹配执行请求 */
export interface MatchExecuteRequest {
  mainFileConfig: MainFileConfig;
  matchFileConfigs: MatchFileConfig[];
  globalStorageConfig: GlobalStorageConfig;
  nullValueConfig: NullValueConfig;
}

/** 匹配执行响应 */
export interface MatchExecuteResponse {
  success: boolean;
  result: MatchResult;
  error?: string;
}

/** 导出执行请求 */
export interface ExportExecuteRequest {
  matchResult: MatchResult;
  exportConfig: ExportConfig;
  mainFileConfig: MainFileConfig;
}

/** 导出执行响应 */
export interface ExportExecuteResponse {
  success: boolean;
  downloadUrl?: string;
  logDownloadUrl?: string;
  unmatchedDownloadUrl?: string;
  error?: string;
}